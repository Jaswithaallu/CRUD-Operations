import express from "express"
import mysql from "mysql"

const app = express();


const db= mysql.createConnection({
    host:"localhost",
    port:"3306" ,
    user:"root",
    password: "password",
    database: 'student'
})
app.get('/',(req, res) => {
    const sql = "select * from student";
    db.query(sql,(err,result)=> {
     if(err) return res.json({Message: err});
     return res.json(result);  
    })
})
app.listen(8081, ()=> {
    console.log("listening");
})